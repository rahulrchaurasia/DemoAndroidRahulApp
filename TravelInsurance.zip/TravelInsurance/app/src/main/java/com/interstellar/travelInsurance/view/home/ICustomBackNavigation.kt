package com.interstellar.travelInsurance.view.home

interface ICustomBackNavigation {

    fun onCustomBackPressed(): Boolean
}