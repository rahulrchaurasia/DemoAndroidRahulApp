package com.interstellar.travelInsurance

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class TravellInsuranceApplication : Application() {
}